"use strict";
var KTSigninGeneral = function() {
    var t, e, r;
    return {
        init: function() {
            t = document.querySelector("#kt_sign_in_form"), 
            e = document.querySelector("#kt_sign_in_submit"), 
            r = FormValidation.formValidation(t, {
                fields: {
                    username: {
                        validators: {
                            regexp: {
                                regexp: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                                message: "The value is not a valid email address"
                            },
                            notEmpty: {
                                message: "Email address is required"
                            }
                        }
                    },
                    password: {
                        validators: {
                            notEmpty: {
                                message: "The password is required"
                            }
                        }
                    }
                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger,
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: ".fv-row",
                        eleInvalidClass: "",
                        eleValidClass: ""
                    })
                }
            }), 
            
            e.addEventListener("click", (function(i) {
                i.preventDefault(), 
                r.validate().then((function(r) {
                    if ("Valid" == r) {
                        e.setAttribute("data-kt-indicator", "on"), 
                        e.disabled = !0;
                        
                        axios.post(e.closest("form").getAttribute("action"), new FormData(t))
                        .then((function(response) {
                            if (response.data.status === false) {
                                // Handle validation errors
                                let errors = response.data.errors;
                                let errorMessages = [];

                                Object.keys(errors).forEach(function(field) {
                                    let errorMessage = errors[field];
                                    let inputField = t.querySelector(`[name="${field}"]`);

                                    if (inputField) {
                                        let errorDiv = document.createElement("div");
                                        errorDiv.classList.add("invalid-feedback");
                                        errorDiv.style.display = "block";
                                        errorDiv.textContent = errorMessage;
                                        
                                        // Remove previous errors
                                        let existingError = inputField.nextElementSibling;
                                        if (existingError && existingError.classList.contains("invalid-feedback")) {
                                            existingError.remove();
                                        }
                                        
                                        inputField.classList.add("is-invalid");
                                        inputField.parentNode.appendChild(errorDiv);
                                    }

                                    errorMessages.push(errorMessage);
                                });

                                Swal.fire({
                                    text: errorMessages.join("\n"),
                                    icon: "error",
                                    buttonsStyling: !1,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });

                            } else {
                                t.reset();
                                Swal.fire({
                                    text: "You have successfully logged in!",
                                    icon: "success",
                                    buttonsStyling: !1,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });

                                const redirectUrl = t.getAttribute("data-kt-redirect-url");
                                if (redirectUrl) location.href = redirectUrl;
                            }
                        }))
                        .catch((function() {
                            Swal.fire({
                                text: "Sorry, looks like there are some errors detected, please try again.",
                                icon: "error",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            });
                        }))
                        .finally(() => {
                            e.removeAttribute("data-kt-indicator");
                            e.disabled = !1;
                        });
                    } else {
                        Swal.fire({
                            text: "Sorry, looks like there are some errors detected, please try again.",
                            icon: "error",
                            buttonsStyling: !1,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        });
                    }
                }));
            }));
        }
    }
}();

KTUtil.onDOMContentLoaded((function() {
    KTSigninGeneral.init()
}));
