
var KTSigninGeneral = function() {
    var t, e, r;
    return {
        init: function() {
            t = document.querySelector("#kt_account_meta_details_form");
            e = document.querySelector("#kt_account_meta_details_submit");

            r = FormValidation.formValidation(t, {
                fields: {
                    min_withdraw: {
                        validators: {
                            notEmpty: {
                                message: "Minimum withdraw is required."
                            },
                            numeric: {
                                message: "Only numbers are allowed."
                            },
                            greaterThan: {
                                min: 0,
                                message: "Minimum withdraw must be greater than 0."
                            }
                        }
                    },
                    max_withdraw: {
                        validators: {
                            notEmpty: {
                                message: "Maximum withdraw is required."
                            },
                            numeric: {
                                message: "Only numbers are allowed."
                            },
                            greaterThan: {
                                min: 0,
                                message: "Maximum withdraw must be greater than 0."
                            }
                        }
                    },
                    withdraw_fee: {
                        validators: {
                            notEmpty: {
                                message: "Withdraw fee is required."
                            },
                            numeric: {
                                message: "Only numbers are allowed."
                            },
                        }
                    },
                    withdraw_daily_limit: {
                        validators: {
                            notEmpty: {
                                message: "Daily limit is required."
                            },
                            numeric: {
                                message: "Only numbers are allowed."
                            },
                        }
                    },
                    withdraw_monthly_limit: {
                        validators: {
                            notEmpty: {
                                message: "Monthly limit is required."
                            },
                            numeric: {
                                message: "Only numbers are allowed."
                            }
                        }
                    }
                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger(),
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: ".fv-row",
                        eleInvalidClass: "",
                        eleValidClass: ""
                    })
                }
            });
            

            e.addEventListener("click", function(i) {
                i.preventDefault(); // Prevent the default form submission
                
                // Validate the form
                r.validate().then(function(status) {
                    if (status === "Valid") {
                        e.setAttribute("data-kt-indicator", "on"); // Show loading indicator
                        e.disabled = true; // Disable the button to prevent multiple submissions
            
                        // Create a FormData object and append the CKEditor content
                        var formData = new FormData(t);
            
                        // Send the form data via axios
                        axios.post(t.getAttribute("action"), formData)
                            .then(function(response) {
                                var res = response.data;
            
                                // Check the response status
                                if (res.status) {
                                    Swal.fire({
                                        text: res.message,
                                        icon: "success",
                                        buttonsStyling: false,
                                        confirmButtonText: "Ok, got it!",
                                        customClass: {
                                            confirmButton: "btn btn-primary"
                                        }
                                    }).then(function(e) {
                                        if (e.isConfirmed) {
                                            // If you need to redirect after successful update
                                            if (redirectUrl) {
                                                location.href = redirectUrl; // Redirect to the provided URL
                                            }
                                        }
                                    });
                                } else {
                                    Swal.fire({
                                        text: "Sorry, " + res.message, // Display error message
                                        icon: "error",
                                        buttonsStyling: false,
                                        confirmButtonText: "Ok, got it!",
                                        customClass: {
                                            confirmButton: "btn btn-primary"
                                        }
                                    });
                                }
                            })
                            .catch(function(error) {
                                // Handle errors in case of request failure
                                Swal.fire({
                                    text: error.message || error, // Show the error message
                                    icon: "error",
                                    buttonsStyling: false,
                                    confirmButtonText: "Ok, got it!",
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                });
                            })
                            .finally(function() {
                                // Remove the loading indicator and re-enable the button
                                e.removeAttribute("data-kt-indicator");
                                e.disabled = false;
                            });
                    } else {
                        // Handle invalid form
                        Swal.fire({
                            text: "Please correct the errors in the form.",
                            icon: "warning",
                            buttonsStyling: false,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-warning"
                            }
                        });
                    }
                });
            });
            
        }
    }
}();


KTUtil.onDOMContentLoaded(function() {
    KTSigninGeneral.init();
});
